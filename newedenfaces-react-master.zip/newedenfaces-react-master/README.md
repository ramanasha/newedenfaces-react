# New Eden Faces (React)

A simple character voting app for the eve online game. Add your favourite characters and start voting !
